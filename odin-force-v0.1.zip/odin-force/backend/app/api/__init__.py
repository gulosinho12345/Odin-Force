"""Camada de API (rotas HTTP)."""
